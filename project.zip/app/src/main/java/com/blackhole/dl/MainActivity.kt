package com.blackhole.dl

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.ContentValues
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            setBackgroundColor(0xFF05030A.toInt())
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        window.decorView.setBackgroundColor(0xFF05030A.toInt())
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        // Keep the page clear of the status bar, navigation bar and keyboard
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        Thread {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                emit("engine", "v" to YoutubeDL.getInstance().version(application))
                updateEngine() // keeps every source working as sites change
            } catch (e: Exception) {
                emit("error", "msg" to "Engine failed to start: ${e.message}")
            }
        }.start()
    }

    private fun emit(type: String, vararg data: Pair<String, Any?>) {
        val o = JSONObject().put("t", type)
        data.forEach { o.put(it.first, it.second) }
        web.post { web.evaluateJavascript("onNative($o)", null) }
    }

    private fun updateEngine() {
        try {
            // Nightly gets extractor fixes (YouTube, TikTok, Instagram...) first
            YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.NIGHTLY)
        } catch (ignored: Exception) {
            try { YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE) }
            catch (ignored: Exception) { /* offline: keep current engine */ }
        }
        emit("engine", "v" to YoutubeDL.getInstance().version(application), "fresh" to true)
    }

    private fun friendly(m: String?): String = when {
        m == null -> "Download failed. Try again."
        m.contains("JavaScript", true) || m.contains("Sign in", true) || m.contains("confirm you", true) ->
            "YouTube blocked this request. Tap the engine chip to update, then retry."
        m.contains("login", true) || m.contains("private", true) -> "This video is private or needs a login."
        else -> m.lines().lastOrNull { it.isNotBlank() }?.take(140) ?: "Download failed. Try again."
    }

    private fun format(q: String) = when (q) {
        "audio" -> "ba/b"
        "best" -> "bv*+ba/b"
        else -> "bv*[height<=$q]+ba/b[height<=$q]/b"
    }

    private fun download(url: String, q: String) {
        val tmp = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
        try {
            emit("stage", "msg" to "Reading link…")
            val info = YoutubeDL.getInstance().getInfo(url)
            emit("info", "title" to info.title)
            val req = YoutubeDLRequest(url).apply {
                addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("-N", "4")
                addOption("--retries", "5")
                addOption("-f", format(q))
                if (q == "audio") { addOption("-x"); addOption("--audio-format", "mp3") }
                else addOption("--merge-output-format", "mp4")
            }
            YoutubeDL.getInstance().execute(req, "dl") { p, eta, _ ->
                emit("progress", "p" to p, "eta" to eta)
            }
            val file = tmp.listFiles()!!.first()
            save(file, q == "audio")
            emit("done", "name" to file.name)
        } catch (e: Exception) {
            emit("error", "msg" to friendly(e.message))
        }
    }

    // Saves into Movies/BlackHole or Music/BlackHole so it shows up in the gallery
    private fun save(f: File, audio: Boolean) {
        val mime = if (audio) "audio/mpeg" else if (f.extension == "webm") "video/webm" else "video/mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, (if (audio) "Music/" else "Movies/") + "BlackHole")
        }
        val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(collection, values)!!
        contentResolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
        f.delete()
    }

    inner class Bridge {
        @JavascriptInterface
        fun paste(): String {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            return cm.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        }

        @JavascriptInterface
        fun download(url: String, q: String) { Thread { this@MainActivity.download(url, q) }.start() }

        @JavascriptInterface
        fun update() { Thread { updateEngine() }.start() }
    }
}
